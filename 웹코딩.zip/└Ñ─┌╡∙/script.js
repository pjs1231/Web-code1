let element = document.getElementById("button");
let winningNumbers = [];
let excludedNumbers = new Set();

element.onclick = () => {
  let result = [];
  while (result.length < 7) {
    let num = parseInt(Math.random() * 45) + 1;
    if (!result.includes(num) && !excludedNumbers.has(num)) {
      result.push(num);
    }
  }
  result.sort((a, b) => a - b); // 번호를 오름차순으로 정렬
  let numberEl = document.getElementsByClassName("number");
  for (let i = 0; i < 7; i++) {
    numberEl[i].innerHTML = result[i];
  }
  updateWinningNumbers(result); // 새로운 번호를 당첨 번호 목록에 추가하여 목록 업데이트
}

let winningList = document.getElementById("winningList");

function addWinningNumber(number) {
  let div = document.createElement("div");
  div.classList.add("number");
  div.textContent = number;
  return div;
}

function updateWinningNumbers(newNumbers) {
  newNumbers.sort((a, b) => a - b); // 새로운 번호를 오름차순으로 정렬
  winningNumbers.push(newNumbers.slice()); // 새로운 당첨 번호를 기록
  let numberRow = document.createElement("div");
  numberRow.classList.add("number-row");
  newNumbers.forEach((number, index) => {
    let numberDiv = addWinningNumber(number);
    numberRow.appendChild(numberDiv);
    if ((index + 1) % 7 === 0 || index === newNumbers.length - 1) { // 한 줄에 7개의 번호를 출력하고자 함 또는 마지막 번호인 경우
      winningList.appendChild(numberRow);
      numberRow = document.createElement("div");
      numberRow.classList.add("number-row");
    }
  });
}

// 번호 제외 기능
function toggleNumber(number) {
  if (excludedNumbers.has(number)) {
    excludedNumbers.delete(number); // 해당 번호를 제외 목록에서 제거
  } else {
    excludedNumbers.add(number); // 해당 번호를 제외 목록에 추가
  }
}

// 숫자 체크박스 생성
let numberButtonsContainer = document.getElementById("numberButtons");
for (let i = 1; i <= 45; i++) {
  let checkboxContainer = document.createElement("div");
  checkboxContainer.classList.add("number-checkbox");
  let checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = `number-${i}`;
  checkbox.addEventListener("change", (event) => toggleNumber(i));
  let label = document.createElement("label");
  label.htmlFor = `number-${i}`;
  label.textContent = i;
  checkboxContainer.appendChild(checkbox);
  checkboxContainer.appendChild(label);
  numberButtonsContainer.appendChild(checkboxContainer);
}
